   =========================================================================
                                M I C R O   F O C U S

                  C L A S S I C   D A T A   F I L E   T O O L S 
   =========================================================================

                            PROJECT ClassicDataToolsDemo
                            ============================

   TABLE OF CONTENTS
   =================
       INTRODUCTION

   INTRODUCTION
   ============

   This demo is used in Classic Data File Tools.
   Follow the Classic Data File Tools tutorial in the documentation.

   =========================================================================
   Micro Focus is a registered trademark of 
   Micro Focus IP Development Limited
   =========================================================================
   Copyright (C) Micro Focus 2003-2020
   All Rights reserved.
